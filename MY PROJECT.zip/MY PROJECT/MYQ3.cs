
using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace MVC_RadioButton.Controllers
{
    public class HomeController : Controller
    {
        public ActionResult Index()
        {
            return View();
        }

        public ActionResult About()
        {
            ViewBag.Message = "Your application description page.";

            return View();
        }

        public ActionResult Contact()
        {
            ViewBag.Message = "Your contact page.";

            return View();
        }

        public JsonResult GetValues()
        {
            List<User> u = new List<Ques>();
            u.Add(new Ques(1, "12"));
            u.Add(new Ques(2, "0"));
            u.Add(new Ques(3, "10"));
            u.Add(new Ques(4, "25"));
            return Json(u.Select(x => new
            {
                ID = x.ID,
                NAME = x.Q
            }));

        }
    }

    public class Ques
    {
        public int ID { get; set; }
        public string Q { get; set; }

        public User(int id, string q)
        {
            ID = id;
            Q = name;
        }
    }
}